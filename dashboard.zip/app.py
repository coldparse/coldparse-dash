# app.py
import dash
from dash import html, dcc
import dash_bootstrap_components as dbc

app = dash.Dash(
    __name__,
    use_pages=True,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True,
    title="coldparse // dashboard",
)
server = app.server  # expose for gunicorn


# ── Sidebar ───────────────────────────────────────────────
# Groups and links live here. Add new AccordionItems as pages are built.
sidebar = html.Div(
    id="sidebar",
    children=[
        dbc.Accordion(
            [
                dbc.AccordionItem(
                    [
                        dbc.NavLink("» Link 1", href="/group1/link1", active="exact", className="sidebar-navlink"),
                        dbc.NavLink("» Link 2", href="/group1/link2", active="exact", className="sidebar-navlink"),
                    ],
                    title="Group 1",
                    className="sidebar-accordion-item",
                ),
                dbc.AccordionItem(
                    [
                        dbc.NavLink("» Link 1", href="/group2/link1", active="exact", className="sidebar-navlink"),
                        dbc.NavLink("» Link 2", href="/group2/link2", active="exact", className="sidebar-navlink"),
                    ],
                    title="Group 2",
                    className="sidebar-accordion-item",
                ),
            ],
            start_collapsed=True,
            flush=True,
        ),
        html.Div("coldparse // dashboard", className="sidebar-footer"),
    ],
)


# ── Top bar ───────────────────────────────────────────────
topbar = html.Div(
    id="topbar",
    children=[
        # Hamburger button
        html.Button(
            id="hamburger",
            children=[html.Span(), html.Span(), html.Span()],
            n_clicks=0,
            title="Toggle navigation",
        ),
        # Logo
        html.A(
            [html.Span("~/"), "coldparse"],
            href="/",
            id="topbar-logo",
        ),
        # Right side status
        html.Div(
            className="topbar-right",
            children=[
                html.Div(
                    className="topbar-status",
                    children=[html.Span(className="status-dot"), "dashboard"],
                )
            ],
        ),
    ],
)


# ── App layout ────────────────────────────────────────────
app.layout = html.Div(
    id="app-container",
    children=[
        # Sidebar overlay — click to close on mobile
        html.Div(id="sidebar-overlay", n_clicks=0),

        topbar,
        sidebar,

        # Page content injected here by Dash pages
        html.Div(
            id="page-content",
            children=dash.page_container,
        ),
    ],
)


# ── Clientside callbacks ──────────────────────────────────
# Toggle sidebar open/closed via hamburger
app.clientside_callback(
    """
    function(n_clicks) {
        document.body.classList.toggle('sidebar-open');
        return null;
    }
    """,
    dash.Output("hamburger", "data-toggled"),
    dash.Input("hamburger", "n_clicks"),
    prevent_initial_call=True,
)

# Close sidebar when overlay is clicked
app.clientside_callback(
    """
    function(n_clicks) {
        if (n_clicks) document.body.classList.remove('sidebar-open');
        return null;
    }
    """,
    dash.Output("sidebar-overlay", "data-closed"),
    dash.Input("sidebar-overlay", "n_clicks"),
    prevent_initial_call=True,
)


# ── Entry point ───────────────────────────────────────────
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8050, debug=False)
